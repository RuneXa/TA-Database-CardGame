<head>
    <title>Main Menu</title>
</head>
<td>Klik pilihan Menu dibawah ini : </td>
<br>
<form>
	<input class="MyButton" type="button" value="Edit Data Musuh" onclick="window.location.href='musuh.php'" /><br><br>
	<input class="MyButton" type="button" value="Edit Deck" onclick="window.location.href='deck.php'" /><br><br>
	<input class="MyButton" type="button" value="Edit kartu" onclick="window.location.href='kartu.php'" /><br><br>
	<input class="MyButton" type="button" value="Edit User" onclick="window.location.href='user.php'" /><br><br>
	<input class="MyButton" type="button" value="Edit Win-rate" onclick="window.location.href='winrate.php'" /><br>
</form>