<head>
    <title>Menu Deck</title>
</head>
	<td>Selamat Datang di Edit Data Deck : </td>
<br>
<form>
	<input class="MyButton" type="button" value="Input Deck Baru" onclick="window.location.href='Deck/inputDeck.php'" /><br><br>
<input class="MyButton" type="button" value="Edit Deck" onclick="window.location.href='Deck/editDeck.php'" /><br><br>
	<input class="MyButton" type="button" value="Delete Deck" onclick="window.location.href='delete/delDeck.php'" /><br><br>
	<input class="MyButton" type="button" value="Kembali ke Main Menu" onclick="window.location.href='index.php'" />
</form>

<?php 
	
	mysql_connect("localhost","root","");
	mysql_select_db("db_tcg");
	$query="select * from tb_deck";
    $exe=mysql_query($query);
           
?>
<table width="600" border="1" cellpadding="1" cellspacing="1">
	<tr>
	<th>ID User</th>
	<th>Kartu</th>
	<tr>
<?php 
    while ($row=mysql_fetch_array($exe)) {
		echo "<tr>";
		echo "<td>".$row["id_user"]."</td>";
		echo "<td>".$row["kode_kartu"]."</td>";
		echo "</tr>";
    }
?>