<head>
    <title>Menu Musuh</title>
</head>
	<td>Selamat Datang di Edit Data Musuh : </td>
<br>
<form>
	<input class="MyButton" type="button" value="Input Musuh Baru" onclick="window.location.href='musuh/inputmusuh.php'" /><br><br>
<input class="MyButton" type="button" value="Edit Musuh" onclick="window.location.href='musuh/editmusuh.php'" /><br><br>
	<input class="MyButton" type="button" value="Delete Musuh" onclick="window.location.href='delete/delmusuh.php'" /><br><br>
	<input class="MyButton" type="button" value="Kembali ke Main Menu" onclick="window.location.href='index.php'" />
</form>

<?php 
	
	mysql_connect("localhost","root","");
	mysql_select_db("db_tcg");
	$query="select * from tb_datamusuh";
    $exe=mysql_query($query);
           
?>
<table width="600" border="1" cellpadding="1" cellspacing="1">
	<tr>
	<th>Nama</th>
	<th>Health</th>
	<th>Attack</th>
	<th>Deskripsi</th>
<?php 
    while ($row=mysql_fetch_array($exe)) {
		echo "<tr>";
		echo "<td>".$row["nama"]."</td>";
		echo "<td>".$row["health"]."</td>";
		echo "<td>".$row["attack"]."</td>";
		echo "<td>".$row["desc"]."</td>";
		echo "</tr>";
    }
?>