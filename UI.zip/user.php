<head>
    <title>Menu User</title>
</head>
	<td>Selamat Datang di Edit Data User : </td>
<br>
<form>
	<input class="MyButton" type="button" value="Input User Baru" onclick="window.location.href='User/inputUser.php'" /><br><br>
<input class="MyButton" type="button" value="Edit User" onclick="window.location.href='User/editUser.php'" /><br><br>
	<input class="MyButton" type="button" value="Delete User" onclick="window.location.href='delete/delUser.php'" /><br><br>
	<input class="MyButton" type="button" value="Kembali ke Main Menu" onclick="window.location.href='index.php'" /><br><br>
</form>

<?php 
	
	mysql_connect("localhost","root","");
	mysql_select_db("db_tcg");
	$query="select * from tb_user";
    $exe=mysql_query($query);
           
?>
<table width="600" border="1" cellpadding="1" cellspacing="1">
	<tr>
	<th>ID User</th>
	<th>Password</th>
	<th>Nama</th>
	<th>Experience</th>
	<tr>
<?php 
    while ($row=mysql_fetch_array($exe)) {
		echo "<tr>";
		echo "<td>".$row["id_user"]."</td>";
		echo "<td>".$row["password"]."</td>";
		echo "<td>".$row["nama"]."</td>";
		echo "<td>".$row["exp"]."</td>";
		echo "</tr>";
    }
?>