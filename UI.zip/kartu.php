<head>
    <title>Menu Kartu</title>
</head>
	<td>Selamat Datang di Edit Data Kartu : </td>
<br>
<form>
	<input class="MyButton" type="button" value="Input Kartu Baru" onclick="window.location.href='Kartu/inputKartu.php'" /><br><br>
<input class="MyButton" type="button" value="Edit Kartu" onclick="window.location.href='Kartu/editKartu.php'" /><br><br>
	<input class="MyButton" type="button" value="Delete Kartu" onclick="window.location.href='delete/delKartu.php'" /><br><br>
	<input class="MyButton" type="button" value="Kembali ke Main Menu" onclick="window.location.href='index.php'" />
</form>

<?php 
	
	mysql_connect("localhost","root","");
	mysql_select_db("db_tcg");
	$query="select * from tb_kartu";
    $exe=mysql_query($query);
           
?>
<table width="600" border="1" cellpadding="1" cellspacing="1">
	<tr>
	<th>Kartu</th>
	<th>Efek</th>
	<th>Warna</th>
	<th>Attack</th>
	<th>Cost</th>
	<tr>
<?php 
    while ($row=mysql_fetch_array($exe)) {
		echo "<tr>";
		echo "<td>".$row["kode_kartu"]."</td>";
		echo "<td>".$row["efek"]."</td>";
		echo "<td>".$row["warna"]."</td>";
		echo "<td>".$row["attack"]."</td>";
		echo "<td>".$row["cost"]."</td>";
		echo "</tr>";
    }
?>