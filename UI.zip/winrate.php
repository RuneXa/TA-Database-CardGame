<head>
    <title>Menu Winrate</title>
</head>
	<td>Selamat Datang di Edit Data Winrate : </td>
<br>
<form>
	<input class="MyButton" type="button" value="Input Winrate Baru" onclick="window.location.href='Winrate/inputWinrate.php'" /><br><br>
<input class="MyButton" type="button" value="Edit Winrate" onclick="window.location.href='Winrate/editWinrate.php'" /><br><br>
	<input class="MyButton" type="button" value="Delete Winrate" onclick="window.location.href='delete/delWinrate.php'" /><br><br>
	<input class="MyButton" type="button" value="Kembali ke Main Menu" onclick="window.location.href='index.php'" />
</form>

<?php 
	
	mysql_connect("localhost","root","");
	mysql_select_db("db_tcg");
	$query="select * from tb_winrate";
    $exe=mysql_query($query);
           
?>
<table width="600" border="1" cellpadding="1" cellspacing="1">
	<tr>
	<th>ID User</th>
	<th>Win</th>
	<th>Loss</th>
	<tr>
<?php 
    while ($row=mysql_fetch_array($exe)) {
		echo "<tr>";
		echo "<td>".$row["id_user"]."</td>";
		echo "<td>".$row["win"]."</td>";
		echo "<td>".$row["loss"]."</td>";
		echo "</tr>";
    }
?>